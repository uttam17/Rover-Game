Uttam Kumaran
CSCI 204 -  Rover Project

PLEASE RUN ON A WINDOWS MACHINE. THERE MAY BE ERRORS FROM AUDIO PLAYING
THE CREATIVE PART IS ZIPPED SEPARATELY FROM THE NORMAL PROJECT. SEE BOTH FILES IN MOODLE.

I decided, due to upcoming events, to use an emphasis of star wars related themes in my project for the creative portion.

The things I changed & why are below:

Tasks Rewritten - To adhere to the theme
Added new items - Bacta tanks, blasters, r2 droids, commlinks, and light sabers
Add new ship components - Fuel tank, Hull, Helmet
	- These relate to the problem faced in the task description
Background color to blue - seemed fitting for the theme of space
Changed titles - Titles of all the three boxes are changed
Directional modifiers - The image of the x-wing (rover) changes depending on the direction you are traveling

**ONLY WORKS IN WINDOWS**
Added sound effects to many aspects of the game. Please test out the buttons and picking up items. Also
the user can press a button on the side to play star wars music in the background as they play.

Additionally,
My broken pieces on the map do not break if the task is not completed in a certain amount of steps.
Professor Peck mentioned that this was ok in the csci204 slack.

RULES
The user must pick up the exact amount in their inventory to fix the part.
All of the parts will be used to fix the component, even other ones.
I was unaware that this was part of the ruleset and my implementation currently does not support this.